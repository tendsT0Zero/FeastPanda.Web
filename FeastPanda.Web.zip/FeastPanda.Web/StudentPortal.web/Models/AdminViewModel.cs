﻿using StudentPortal.web.Models.Entities;

namespace StudentPortal.web.Models
{
    public class AdminViewModel
    {
        public List<Menu> MenuItems { get; set; }
        public List<Customer> Customers { get; set; }
        public List<InventoryItem> InventoryItems { get; set; }
        public List<Order> Orders { get; set; }
        public List<Employee> Employees { get; set; }
    }
}
