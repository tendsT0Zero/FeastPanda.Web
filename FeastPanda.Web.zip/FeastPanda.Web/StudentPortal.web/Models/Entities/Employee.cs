﻿namespace StudentPortal.web.Models.Entities
{
    public class Employee
    {
        public int Id { get; set; } // Employee ID
        public string Name { get; set; } // Employee Name
        public string Email { get; set; } // Employee Email
        public string Phone { get; set; } // Employee Phone
        public string Password { get; set; }
        public string Role { get; set; } // Employee Role (e.g., Chef, Waiter, Manager)
    }

}
