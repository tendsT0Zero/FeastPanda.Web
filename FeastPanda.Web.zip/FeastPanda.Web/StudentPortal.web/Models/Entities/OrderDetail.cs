﻿using System.ComponentModel.DataAnnotations.Schema;

namespace StudentPortal.web.Models.Entities
{
    public class OrderDetail
    {
        public int Id { get; set; } // Primary key for OrderDetail
        public int OrderId { get; set; } // Foreign key to Order
        public int MenuId { get; set; } // Foreign key to Menu
        public int Quantity { get; set; } // Quantity of the item ordered

        [Column(TypeName = "decimal(18, 2)")]
        public decimal UnitPrice { get; set; } // Unit price of the menu item

        // Navigation properties
        public Order Order { get; set; } // Navigation property to the Order entity
        public Menu Menu { get; set; } // Navigation property to the Menu entity
    }
}
