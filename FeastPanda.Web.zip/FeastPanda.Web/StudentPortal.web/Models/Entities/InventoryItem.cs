﻿using System.ComponentModel.DataAnnotations.Schema;

namespace StudentPortal.web.Models.Entities
{
    public class InventoryItem
    {
        public int Id { get; set; } // Item ID
        public string ItemName { get; set; } // Name of the item
        public int Quantity { get; set; } // Quantity of the item in stock
        [Column(TypeName = "decimal(18, 2)")]
        public decimal UnitPrice { get; set; } // Price per unit of the item
    }

}
