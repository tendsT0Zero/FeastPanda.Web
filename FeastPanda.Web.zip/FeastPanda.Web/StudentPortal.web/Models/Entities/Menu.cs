﻿using System.ComponentModel.DataAnnotations.Schema;

namespace StudentPortal.web.Models.Entities
{
    public class Menu
    {
        public int Id { get; set; } // Primary key for the menu item
        public string Name { get; set; } // Menu item name
        [Column(TypeName = "decimal(18, 2)")]
        public decimal Price { get; set; } // Menu item price
        public byte[] Image { get; set; } // Image stored as a byte array (BLOB)

        [NotMapped]  // Prevent this property from being mapped to the database
        public IFormFile ImageFile { get; set; }  // Used for file uploads
    }
}
