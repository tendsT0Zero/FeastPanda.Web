﻿namespace StudentPortal.web.Models.Entities
{
    public class Customer
    {
        public Customer()
        {
            Orders = new HashSet<Order>(); // Initialize the Orders collection
           
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }

        public ICollection<Order> Orders { get; set; }
        
    }

}
