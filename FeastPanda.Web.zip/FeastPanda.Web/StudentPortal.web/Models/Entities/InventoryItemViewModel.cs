﻿namespace StudentPortal.web.Models.Entities
{
    public class InventoryItemViewModel
    {
        public string ItemName { get; set; } // Name of the item
        public int Quantity { get; set; } // Quantity of the item in stock
        public decimal UnitPrice { get; set; } // Price per unit of the item
    }
}
