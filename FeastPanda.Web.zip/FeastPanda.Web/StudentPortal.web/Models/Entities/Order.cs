﻿using System;
using System.Collections.Generic;

namespace StudentPortal.web.Models.Entities
{
    public class Order
    {
        public Order()
        {
            OrderDetails = new HashSet<OrderDetail>(); // Initialize the OrderDetails collection
        }

        public int OrderId { get; set; } // Primary key for the Order
        public int CustomerId { get; set; } // Foreign key to the Customer
        public DateTime Date { get; set; } // Date of the order
        public string ShippingAddress { get; set; } // Shipping address for the order
        public bool IsCompleted { get; set; } // Add flag to check if the order is completed
        public int Progress { get; set; } // Add progress value from 0 to 100

        // Navigation properties
        public Customer Customer { get; set; } // Navigation property for Customer
        public ICollection<OrderDetail> OrderDetails { get; set; } // Collection of OrderDetails

    }
}
