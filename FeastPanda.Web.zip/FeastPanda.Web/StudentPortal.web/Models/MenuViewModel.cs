﻿using System.ComponentModel.DataAnnotations.Schema;

namespace StudentPortal.web.Models
{
    public class MenuViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } // Menu item name
        public decimal Price { get; set; } // Menu item price
        public IFormFile Image { get; set; }
    }
}
