﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentPortal.web.Data;
using StudentPortal.web.Models.Entities;
using System;
using System.Linq;

namespace StudentPortal.web.Controllers
{
    public class CartController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public CartController(ApplicationDbContext _dbContext)
        {
            dbContext = _dbContext;
        }

        // Display cart items for the logged-in customer
        public IActionResult Index()
        {
            var customerId = HttpContext.Session.GetInt32("CustomerId");

            if (customerId == null)
            {
                return RedirectToAction("Index", "Login");
            }

            var cartItems = dbContext.carts
                                     .Include(c => c.Menu)
                                     .Where(c => c.CustomerId == customerId.Value)
                                     .ToList();
            return View(cartItems);
        }

        // Display the checkout page
        [HttpGet]
        public IActionResult Checkout()
        {
            var customerId = HttpContext.Session.GetInt32("CustomerId");

            if (customerId == null)
            {
                return RedirectToAction("Index", "Login");
            }

            var cartItems = dbContext.carts
                                     .Include(c => c.Menu)
                                     .Where(c => c.CustomerId == customerId.Value)
                                     .ToList();
            return View(cartItems);
        }

        // Handle the order submission and store in the database
        [HttpPost]
        public IActionResult ConfirmOrder(string shippingAddress, List<int> itemIds, List<int> quantities)
        {
            var customerId = HttpContext.Session.GetInt32("CustomerId");

            if (customerId == null)
            {
                return RedirectToAction("Index", "Login");
            }

            var cartItems = dbContext.carts
                                     .Include(c => c.Menu)
                                     .Where(c => c.CustomerId == customerId.Value && itemIds.Contains(c.Id))
                                     .ToList();

            // Create the new order
            var order = new Order
            {
                CustomerId = customerId.Value,
                Date = DateTime.Now,
                ShippingAddress = shippingAddress
            };

            dbContext.orders.Add(order);
            dbContext.SaveChanges(); // Save to generate the OrderId

            // Add order details
            for (int i = 0; i < cartItems.Count; i++)
            {
                cartItems[i].Quantity = quantities[i]; // Update quantity from form

                var orderDetail = new OrderDetail
                {
                    OrderId = order.OrderId,
                    MenuId = cartItems[i].MenuId,
                    Quantity = cartItems[i].Quantity,
                    UnitPrice = cartItems[i].UnitPrice
                };

                dbContext.orderDetails.Add(orderDetail);
            }

            // Clear the cart for the customer after placing the order
            dbContext.carts.RemoveRange(cartItems);
            dbContext.SaveChanges(); // Commit the changes

            return RedirectToAction("OrderSuccess");
        }

        // Show order success page
        public IActionResult OrderSuccess()
        {
            return View();
        }
    }
}
