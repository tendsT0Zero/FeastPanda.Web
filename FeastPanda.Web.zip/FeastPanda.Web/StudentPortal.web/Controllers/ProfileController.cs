﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using StudentPortal.web.Data;
using StudentPortal.web.Models.Entities;
using System.Linq;

namespace StudentPortal.web.Controllers
{
    public class ProfileController : Controller
    {
        private readonly ApplicationDbContext _dbContext;

        public ProfileController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        // GET: Profile/Index
        public IActionResult Index()
        {
            var customerId = HttpContext.Session.GetInt32("CustomerId");
            if (customerId == null)
            {
                return RedirectToAction("Index", "Login");
            }

            var customer = _dbContext.customers.FirstOrDefault(c => c.Id == customerId);
            return View(customer);  // Pass the customer details to the view
        }

        //// GET: Profile/MakeOrder
        //public IActionResult MakeOrder()
        //{
        //    // Display available menu items to make an order
        //    var menuItems = _dbContext.menus.ToList();
        //    return View(menuItems);  // Pass menu items to the view
        //}

        //// POST: Profile/PlaceOrder
        //[HttpPost]
        //public IActionResult PlaceOrder(int[] menuItemIds, int[] quantities)
        //{
        //    var customerId = HttpContext.Session.GetInt32("CustomerId");
        //    if (customerId == null)
        //    {
        //        return RedirectToAction("Index", "Login");
        //    }

        //    var order = new Order
        //    {
        //        CustomerId = customerId.Value,
        //        Date = System.DateTime.Now,
        //        OrderDetails = menuItemIds.Select((id, index) => new OrderDetail
        //        {
        //            MenuId = id,
        //            Quantity = quantities[index],
        //            UnitPrice = _dbContext.menus.Find(id).Price
        //        }).ToList()
        //    };

        //    _dbContext.orders.Add(order);
        //    _dbContext.SaveChanges();

        //    return RedirectToAction("TrackOrder");  // Redirect to track order after placing
        //}

        // GET: Profile/TrackOrder
        public IActionResult TrackOrder()
        {
            var customerId = HttpContext.Session.GetInt32("CustomerId");
            if (customerId == null)
            {
                return RedirectToAction("Index", "Login");
            }

            // Get only the orders that are not completed
            var orders = _dbContext.orders
                .Where(o => o.CustomerId == customerId.Value && !o.IsCompleted)
                .ToList();

            return View(orders);  // Pass the customer's incomplete orders to the view
        }

        // GET: Profile/EditProfile
        public IActionResult EditProfile()
        {
            var customerId = HttpContext.Session.GetInt32("CustomerId");
            if (customerId == null)
            {
                return RedirectToAction("Index", "Login");
            }

            var customer = _dbContext.customers.FirstOrDefault(c => c.Id == customerId);
            return View(customer);  // Pass the customer's current details to the view
        }

     
        [HttpPost]
        public IActionResult EditProfile(Customer model)
        {
            if (ModelState.IsValid)
            {
                var customer = _dbContext.customers.FirstOrDefault(c => c.Id == model.Id);
                if (customer != null)
                {
                    customer.Name = model.Name;
                    customer.Email = model.Email;
                    customer.Phone = model.Phone;
                    customer.Address = model.Address;
                    _dbContext.SaveChanges();
                }

                return RedirectToAction("Index");
            }

            return View(model);  // Reload the page if validation fails
        }
    }
}
