﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentPortal.web.Data;
using StudentPortal.web.Models.Entities;
using System.Linq;

namespace StudentPortal.web.Controllers
{
    public class ChefController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public ChefController(ApplicationDbContext _dbContext)
        {
            dbContext = _dbContext;
        }

        
        public IActionResult Index()
        {
            
            var chefEmail = User.Identity.Name; 
            var orders = dbContext.orders
                                  .Include(o => o.OrderDetails)
                                  .ThenInclude(od => od.Menu)
                                  .Where(o => !o.IsCompleted) 
                                  .ToList();

            return View(orders);
        }

      
        [HttpPost]
        public IActionResult UpdateProgress(int orderId, int progress)
        {
            var order = dbContext.orders.FirstOrDefault(o => o.OrderId == orderId);
            if (order != null)
            {
                order.Progress = progress;
                dbContext.SaveChanges();
            }
            return Ok();
        }

        
        [HttpPost]
        public IActionResult MarkAsDone(int orderId)
        {
            var order = dbContext.orders.FirstOrDefault(o => o.OrderId == orderId);
            if (order != null)
            {
                order.IsCompleted = true;
                dbContext.SaveChanges();
            }
            return RedirectToAction("Index");
        }

      
        [HttpGet]
        public IActionResult EditProfile()
        {
            var chefEmail = User.Identity.Name; 
            var chef = dbContext.employees.FirstOrDefault(e => e.Email == chefEmail);
            return View(chef);
        }

        [HttpPost]
        public IActionResult EditProfile(Employee model)
        {
            var chefEmail = User.Identity.Name;
            var chef = dbContext.employees.FirstOrDefault(e => e.Email == chefEmail);
            if (chef != null)
            {
                chef.Name = model.Name;
                chef.Phone = model.Phone;
                chef.Password = model.Password; 
                dbContext.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult AddMenuItem()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddMenuItem(Menu model)
        {
            if (ModelState.IsValid)
            {
                dbContext.menus.Add(model);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(model);
        }

    }
}
