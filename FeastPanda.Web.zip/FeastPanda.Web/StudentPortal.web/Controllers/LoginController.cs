﻿using Microsoft.AspNetCore.Mvc;
using StudentPortal.web.Data;
using StudentPortal.web.Models;
using StudentPortal.web.Models.Entities;
using System.Linq;

namespace StudentPortal.web.Controllers
{
    public class LoginController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public LoginController(ApplicationDbContext _dbContext)
        {
            dbContext = _dbContext;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(LoginViewModel model)
        {
            if (model == null || !ModelState.IsValid)
            {
                return View(model);
            }

            if (model.Role.Equals("Admin"))
            {
                if (model.Email.Equals("nayeemofficial80@gmail.com") && model.Password.Equals("1234"))
                {
                    return RedirectToAction("Index", "Admin");
                }
                return View(model);
            }
            else if (model.Role.Equals("Chef"))
            {
                var chef = dbContext.employees
                            .FirstOrDefault(em => em.Email == model.Email && em.Password == model.Password);

                if (chef != null)
                {
                    return RedirectToAction("Index", "Chef");
                }

                ModelState.AddModelError("", "Invalid Chef credentials.");
                return View(model);
            }
            else
            {
                var customer = dbContext.customers
                                .FirstOrDefault(c => c.Email == model.Email && c.Password == model.Password);

                if (customer != null)
                {
                    // Store CustomerId in the session
                    HttpContext.Session.SetInt32("CustomerId", customer.Id);

                    return RedirectToAction("Index", "Profile");
                }

                ModelState.AddModelError("", "Invalid Customer credentials.");
                return View(model);
            }
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear(); // Clear session data
            return RedirectToAction("Index", "Login");
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View(); 
        }

        [HttpPost]
        
        public IActionResult Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                
                var existingCustomer = dbContext.customers.FirstOrDefault(c => c.Email == model.Email);
                if (existingCustomer != null)
                {
                    ModelState.AddModelError("Email", "This email is already registered.");
                    return View(model); 
                }

               
                var customer = new Customer
                {
                    Name = model.Name,
                    Email = model.Email,
                    Password = model.Password, 
                    Phone = model.Phone,
                    Address = model.Address
                };


                dbContext.customers.Add(customer);
                dbContext.SaveChanges();


                return RedirectToAction("Index", "Login");
            }


            return View(model);
        }

    }
}
