﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentPortal.web.Data;
using StudentPortal.web.Models;
using StudentPortal.web.Models.Entities;

namespace StudentPortal.web.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext dbContext;
        public AdminController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<IActionResult> IndexAsync()
        {
            var menuItems = await dbContext.menus.ToListAsync();
            var customers = await dbContext.customers.ToListAsync();  // Fetch customers
            var inventoryItems = await dbContext.inventoryitems.ToListAsync(); // Fetch inventory
            var orders = await dbContext.orders.ToListAsync();
            var employees = await dbContext.employees.ToListAsync();

            var viewModel = new AdminViewModel
            {
                MenuItems = menuItems,
                Customers = customers,
                InventoryItems = inventoryItems,
                Orders = orders,
                Employees = employees
            };

            return View(viewModel);
        }
        [HttpGet]
        public async Task<IActionResult> AddnewCustomer()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddnewCustomer(CustomerViewModel viewModel)
        {
            var customer = new Customer
            {
                Name = viewModel.Name,
                Phone = viewModel.Phone,
                Email = viewModel.Email,
                Address = viewModel.Address,
                Password = viewModel.Password
            };
            await dbContext.customers.AddAsync(customer);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("Index", "Admin");

        }
        [HttpGet]
        public async Task<IActionResult> EditCustomer(int Id)
        {
            var customer = await dbContext.customers.FindAsync(Id);
            return View(customer);
        }
        [HttpPost]
        public async Task<IActionResult> EditCustomer(Customer model)
        {
            var customer = await dbContext.customers.FindAsync(model.Id);
            if (customer != null)
            {
                customer.Name = model.Name;
                customer.Email = model.Email;
                customer.Phone = model.Phone;
                customer.Address = model.Address;
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("Index", "Admin");
        }
        [HttpPost]
        public async Task<IActionResult> DeleteCustomer(Customer model)
        {
            var customer = await dbContext.customers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == model.Id);
            if (customer != null)
            {
                dbContext.customers.Remove(customer);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("Index", "Admin");
        }
        [HttpGet]
        public async Task<IActionResult> EditInventory(int Id)
        {
            var inventoryitem = await dbContext.inventoryitems.FindAsync(Id);
            return View(inventoryitem);
        }
        [HttpPost]
        public async Task<IActionResult> EditInventory(InventoryItem model)
        {
            var inventoryitem = await dbContext.inventoryitems.FindAsync(model.Id);
            if (inventoryitem != null)
            {
                inventoryitem.ItemName = model.ItemName;
                inventoryitem.Quantity = model.Quantity;
                inventoryitem.UnitPrice = model.UnitPrice;

                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("Index", "Admin");
        }
        [HttpPost]
        public async Task<IActionResult> DeleteInventory(InventoryItem model)
        {
            var item = await dbContext.inventoryitems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == model.Id);
            if (item != null)
            {
                dbContext.inventoryitems.Remove(item);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("Index", "Admin");
        }
        [HttpGet]
        public async Task<IActionResult> AddnewInventoryItem()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddnewInventoryItem(InventoryItemViewModel viewModel)
        {
            var inventoryitem = new InventoryItem
            {
                ItemName = viewModel.ItemName,
                Quantity = viewModel.Quantity,
                UnitPrice = viewModel.UnitPrice
            };
            await dbContext.inventoryitems.AddAsync(inventoryitem);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("Index", "Admin");
        }
        [HttpPost]
        public async Task<IActionResult> AddMenuItem(MenuViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Convert the uploaded image to a byte array
                byte[] imageData = null;
                if (model.Image != null)
                {
                    using (var memoryStream = new MemoryStream())
                    {
                        await model.Image.CopyToAsync(memoryStream);
                        imageData = memoryStream.ToArray();
                    }
                }

                // Create a new Menu entity and set its properties
                var menuItem = new Menu
                {
                    Name = model.Name,
                    Price = model.Price,
                    Image = imageData
                };

                // Save the menu item to the database
                dbContext.menus.Add(menuItem);
                await dbContext.SaveChangesAsync();

                // Redirect to a list of menu items or another action after adding the item
                return RedirectToAction("Index");
            }

            // If the model state is invalid, return the view with the current model
            return View(model);
        }
        [HttpGet]
        public async Task<IActionResult> AddnewEmployee()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddnewEmployee(EmployeeViewModel viewModel)
        {
            var employee = new Employee
            {
                Name = viewModel.Name,
                Phone = viewModel.Phone,
                Email = viewModel.Email,
                Password = viewModel.Password,
                Role = viewModel.Role
            };
            await dbContext.employees.AddAsync(employee);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("Index", "Admin");
        }
        [HttpGet]
        public async Task<IActionResult> EditEmployee(int Id)
        {
            var employee = await dbContext.employees.FindAsync(Id);
            return View(employee);
        }
        [HttpPost]
        public async Task<IActionResult> EditEmployee(Employee model)
        {
            var employee = await dbContext.employees.FindAsync(model.Id);
            if (employee != null)
            {
                employee.Name = model.Name;
                employee.Email = model.Email;
                employee.Phone = model.Phone;
                employee.Role = model.Role;
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("Index", "Admin");
        }
        [HttpPost]
        public async Task<IActionResult> DeleteEmployee(Employee model)
        {
            var employee = await dbContext.employees.AsNoTracking().FirstOrDefaultAsync(x => x.Id == model.Id);
            if (employee != null)
            {
                dbContext.employees.Remove(employee);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("Index", "Admin");
        }
        [HttpGet]
        public async Task<IActionResult> EditMenu(int Id)
        {
            // Find the menu item by its Id
            var menuItem = await dbContext.menus.FindAsync(Id);

            if (menuItem == null)
            {
                return NotFound();
            }

            // Return the view with the menu item to be edited
            return View(menuItem);
        }

        [HttpPost]
        public async Task<IActionResult> EditMenu(Menu model)
        {
            var menuItem = await dbContext.menus.FindAsync(model.Id);

            if (menuItem != null)
            {
                // Update the menu item properties
                menuItem.Name = model.Name;
                menuItem.Price = model.Price;

                // If a new image file is uploaded, process it
                if (model.ImageFile != null)
                {
                    using (var memoryStream = new MemoryStream())
                    {
                        await model.ImageFile.CopyToAsync(memoryStream);
                        menuItem.Image = memoryStream.ToArray();  // Convert to byte[] and store
                    }
                }

                // Save the changes to the database
                await dbContext.SaveChangesAsync();
            }

            return RedirectToAction("Index", "Admin");
        }
        [HttpPost]
        public async Task<IActionResult> DeleteMenu(Menu model)
        {
            var menu = await dbContext.menus.AsNoTracking().FirstOrDefaultAsync(x => x.Id == model.Id);
            if (menu != null)
            {
                dbContext.menus.Remove(menu);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("Index", "Admin");
        }

    }
}
