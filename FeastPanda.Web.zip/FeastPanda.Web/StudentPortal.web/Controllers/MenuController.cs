﻿using Microsoft.AspNetCore.Mvc;
using StudentPortal.web.Data;
using StudentPortal.web.Models.Entities;
using System.Linq;

namespace StudentPortal.web.Controllers
{
    public class MenuController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public MenuController(ApplicationDbContext _dbContext)
        {
            dbContext = _dbContext;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var menuItems = dbContext.menus.ToList(); // Fetch all menu items
            return View(menuItems); // Pass the menu items to the view
        }

        [HttpPost]
        public IActionResult AddToCart(int menuItemId, int quantity)
        {
            // Check if the customer is logged in by checking the session
            var customerId = HttpContext.Session.GetInt32("CustomerId");

            if (customerId == null)
            {
                // Redirect to login if the user is not logged in
                return RedirectToAction("Index", "Login");
            }

            // If customer is logged in, proceed to add the item to the cart
            var menuItem = dbContext.menus.Find(menuItemId);
            if (menuItem != null)
            {
                var cart = new Cart
                {
                    CustomerId = customerId.Value, // Use the customer ID from the session
                    MenuId = menuItemId,
                    Quantity = quantity,
                    UnitPrice = menuItem.Price,
                    Date = DateTime.Now
                };
                dbContext.carts.Add(cart);
                dbContext.SaveChanges();
            }

            return RedirectToAction("Index");
        }
    }
}
