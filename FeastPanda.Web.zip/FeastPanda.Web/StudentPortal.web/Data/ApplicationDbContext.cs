﻿using Microsoft.EntityFrameworkCore;
using StudentPortal.web.Models.Entities;

namespace StudentPortal.web.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Customer> customers { get; set; }
        public DbSet<Order> orders { get; set; }
        public DbSet<OrderDetail> orderDetails { get; set; }
        public DbSet<InventoryItem> inventoryitems { get; set; }
        public DbSet<Employee> employees { get; set; }
        public DbSet<Menu> menus { get; set; }
        public DbSet<Cart> carts { get; set; } // Add Cart DbSet

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // One-to-Many: Customer has many Orders
            modelBuilder.Entity<Order>()
                .HasOne(o => o.Customer)
                .WithMany(c => c.Orders)
                .HasForeignKey(o => o.CustomerId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete from Customer to Orders

            // Many-to-One: Cart -> Customer
            modelBuilder.Entity<Cart>()
                .HasOne(c => c.Customer)
                .WithMany() // No navigation collection in Customer for carts
                .HasForeignKey(c => c.CustomerId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete from Customer to Cart

            // Many-to-One: Cart -> Menu
            modelBuilder.Entity<Cart>()
                .HasOne(c => c.Menu)
                .WithMany() // No navigation collection in Menu for carts
                .HasForeignKey(c => c.MenuId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete from Menu to Cart

            // One-to-Many: Order has many OrderDetails
            modelBuilder.Entity<OrderDetail>()
                .HasOne(od => od.Order)
                .WithMany(o => o.OrderDetails)
                .HasForeignKey(od => od.OrderId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete from Order to OrderDetails

            // Many-to-One: OrderDetail -> Menu
            modelBuilder.Entity<OrderDetail>()
                .HasOne(od => od.Menu)
                .WithMany() // No navigation collection in Menu for order details
                .HasForeignKey(od => od.MenuId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete from Menu to OrderDetail

            base.OnModelCreating(modelBuilder);
        }
    }
}
