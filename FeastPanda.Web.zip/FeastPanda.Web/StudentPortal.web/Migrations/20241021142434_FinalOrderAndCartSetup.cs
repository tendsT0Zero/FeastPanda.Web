﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StudentPortal.web.Migrations
{
    /// <inheritdoc />
    public partial class FinalOrderAndCartSetup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ShippingAddress",
                table: "orders",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ShippingAddress",
                table: "orders");
        }
    }
}
